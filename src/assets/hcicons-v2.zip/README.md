# Cashmere Icons Download Bundle

**Contents:**
- **_icons.scss**: some helper styles for icons. change the prefix to suit your app's needs
- **_mixins.scss**: additional helper mixins for icons.
- **app-icons-readme-example.md**: an example of icon instructions you should include in your own app's main README.md file. fill in the appropriate icon prefixes and file paths to suit your app
- **/generated**: folder of the generated files for the hcicons font as output by [IcoMoon](https://icomoon.io/app)
- **/pngs**: folder of all icons as pngs
- **/svgs**: folder of all icons as svgs